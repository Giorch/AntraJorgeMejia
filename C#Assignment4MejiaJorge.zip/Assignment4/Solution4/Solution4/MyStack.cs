﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution4
{
    public class MyStack<T>
    {
        public Stack<T> Stack { get; set; }

        public int Count()
        {
            return Stack.Count;
        }

        public T Pop()
        {
            return Stack.Pop();
        }

        public void Push(T t)
        {
            Stack.Push(t);
        }
    }
}
