﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution4
{
    public class Entity
    {
        public int Id { get; set; }
    }
    public class GenericRepository<T> : IRepository<T> where T : Entity
    {
        public List<T> Items { get; set; }
        public List<T> SavedItems { get; set; }
        public void Add(T item)
        {
            Items.Add(item);
        }

        public IEnumerable<T> GetAll()
        {
            return Items;
        }

        public T GetById(int id)
        {
            for(int i = 0; i < Items.Count; i++)
                if(Items[i].Id == id)
                {
                    return Items[i];
                }

            throw new IndexOutOfRangeException("Index was out of range");
        }

        public void Remove(T item)
        {
            Items.Remove(item);
            
        }

        public void Save()
        {
            SavedItems = Items.ToList();
            
        }
    }

}
