﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution4
{
    internal class MyList<T>
    {
        public List<T> List { get; set; }

        public void Add(T element)
        {
            List.Add(element);
        }
        public T Remove(int index)
        {
            T element = List[index];
            List.RemoveAt(index);
            return element;
        }
        public bool Contains(T element)
        {
            return List.Contains(element);
        }
        public void Clear()
        {
            List.Clear();
        }
        void InsertAt(T element, int index)
        {
            if (index < 0)
                throw new ArgumentOutOfRangeException("index was out of range");
            List.Insert(index, element);

        }
        public void DeleteAt(int index)
        {
            List.RemoveAt(index);

        }
        public T Find(int index)
        {
            for (int i = 0; i < List.Count; i++)
                if(i == index)
                { return List[i]; }

            throw new ArgumentOutOfRangeException("index was out of range");
        }
    }
}
