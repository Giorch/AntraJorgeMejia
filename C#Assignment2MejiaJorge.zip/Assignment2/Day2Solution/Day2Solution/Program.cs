﻿// See https://aka.ms/new-console-template for more information
using System.Text;
   

List<string> items = new List<string>();
int[] rotateNum = { 3, 2, 4, -1 };
int[] sequence = { 0, 1, 1, 8, 3, 3, 5, };
int[] frequence = { 0, 1, 1, 2, 2, 2, 8, 3, 3, 5, 8, 8, 10 };
string palindromes = "Hi,exe? ABBA! Hog fully a string: ExE. Bob. ExE";
string url = "https://www.apple.com/iphone";

while (true)
{

    Console.WriteLine("\n1. Copy Array");
    Console.WriteLine("2. Manage List");
    Console.WriteLine("3. Find Primes");
    Console.WriteLine("4. Rotate");
    Console.WriteLine("5. Longest Sequence");
    Console.WriteLine("6. Highest Frequence");
    Console.WriteLine("7. Reverse String");
    Console.WriteLine("8: Reverse 2");
    Console.WriteLine("10: URL Parsing");
    Console.WriteLine("0. Exit");
    int selection;
    while (true)
    {
        string input = Console.ReadLine();
        if (Int32.TryParse(input, out selection))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }
    switch (selection)
    {
        case 0:
            return;
        case 1:
            CopyArray();
            break;
        case 2:
            ManageList(ref items);
            break;
        case 3:
            Console.Write("Enter starting Range: ");
            int start;
            while (true)
            {
                string input = Console.ReadLine();
                if (Int32.TryParse(input, out start))
                {
                    break;
                }
                Console.Write("Please enter a number: ");
            }
            Console.Write("Enter ending Range: ");
            int end;
            while (true)
            {
                string input = Console.ReadLine();
                if (Int32.TryParse(input, out end))
                {
                    break;
                }
                Console.Write("Please enter a number: ");
            }

            int[] numbers = FindPrimesInRange(start, end);

            for(int i = 0; i < numbers.Length; i++)
            {
                if(numbers[i] != 0)
                Console.Write("{0}, ",numbers[i]);
            }
            break;
        case 4:
            RotateArray(rotateNum, 2, rotateNum.Length);
            break;
        case 5:
            LongestSequence(sequence);
            break;
        case 6:
            HighestFrequency(frequence);
            break;
        case 7:
            Console.Write("Input: ");
            string sInput = Console.ReadLine();
            Console.WriteLine(ReverseString(sInput));
            break;
        case 8:
            Console.Write("Input: ");
            string gInput = Console.ReadLine();
            ReverseGrammar(gInput);
            break;
        case 9:
            Palindrome(palindromes);
            break;
        case 10:
            URLParse(url);
            break;
    }
}


void CopyArray()
{
    int[] numArray = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    int[] copyArray = new int[numArray.Length];

    for (int i = 0; i < numArray.Length; i++)
    {
        copyArray[i] = numArray[i];
        Console.WriteLine(copyArray[i]);
    }
}

void ManageList(ref List<string> list)
{
    Console.WriteLine("\n1. Add (use +)");
    Console.WriteLine("\n2. Clear (use -)");
    Console.WriteLine("\n3. Remove (use --)\n");
    foreach(string item in list)
    {
        Console.WriteLine(item);
    }
    StringBuilder input = new StringBuilder(Console.ReadLine());
    if(input[0] == '+')
    {
        input.Remove(0, 1);
        list.Add(input.ToString());
    }
    else if(input[0] == '-' && input[1] == '-')
    {
        list.Clear();
    }
    else if(input[0] == '-')
    {
        input.Remove(0, 1);
        foreach(string s in list)
        {
            if (s == input.ToString()) 
            {
                list.Remove(s);
                break;
            }
        }
    }


}

static int[] FindPrimesInRange(int start, int end)
{
    bool isPrime = true;
    int[] primes = new int[end - start];
    int size = 0;
    for (int i = start; i < end; i++)
    {
        if (i == 0) continue;
        if (i == 2)
        {
            primes[size] = i; 
            size++;
            continue;
        }
        if (i % 2 == 0) continue;


        int limit = (int)Math.Floor(Math.Sqrt(i));
        for(int j = 3; j <= limit; j += 2)
        {

            if(i % j == 0)
            {
                isPrime = false;
                break;
              
            }
        }
        if (isPrime == true)
        {
            primes[size] = i;
            size++;
        }
        isPrime = true;   
        


    }
    return primes;
}

void RotateArray(int[] numbers, int k, int length)
{
    Console.WriteLine("Input");
    for (int i = 0; i < numbers.Length; i++)
    {
        if (numbers[i] != 0)
            Console.Write("{0}, ", numbers[i]);
    }
    Console.WriteLine();
    List<int[]> sumArray = new List<int[]>();
    if (k < 0 || k >= length)
    {
        return;
    }
    for (int i = 0; i < k; i++)
    {
        int last = numbers[length - 1];
        for (int j = length - 2; j >= 0; j--)
        {
            numbers[j + 1] = numbers[j];
        }
        numbers[0] = last;
        int[] arrayBuffer;
        arrayBuffer = (int[])numbers.Clone();
        sumArray.Add(arrayBuffer);
    }

    
    
    for(int i = 0; sumArray.Count > 1; i++)
    {
        Console.WriteLine("Output");
        for(int j = 0; j < length; j++)
        {
            sumArray[0][j] += sumArray[1][j];
            Console.Write("{0}, ",sumArray[0][j]);
        }
        sumArray.RemoveAt(1);
       
    }
    Console.WriteLine();
   
}

void LongestSequence(int[] numbers)
{
    int biggestNum = 0;
    Console.WriteLine("Input");
    for (int i = 0; i < numbers.Length; i++)
    {
        Console.Write("{0} ", numbers[i]);  
        if(numbers[i] > biggestNum)
        {
            biggestNum = numbers[i];
        }
    }

    int sequenceCount = 0;
    int largestSequence = 0;
    int largestNumber = -1;

    for(int j = 0; j < biggestNum; j++)
    {
        for(int i = 0; i < numbers.Length; i++)
        {
            if(numbers[i] == j)
            {
                sequenceCount++;
            }
        }
        if(sequenceCount > largestSequence)
        {
            largestSequence = sequenceCount;
            largestNumber = j;
        }
        sequenceCount = 0;
    }
    Console.WriteLine("Output");
    for (int i = 0; i < numbers.Length; i++)
    {
        if(numbers[i] == largestNumber)
        {
            Console.Write("{0} ", numbers[i]);
        }
    }
    Console.WriteLine();
}

void HighestFrequency(int[] numbers)
{
    int biggestNum = 0;
    Console.WriteLine("Input");
    for (int i = 0; i < numbers.Length; i++)
    {
        Console.Write("{0} ", numbers[i]);
        if (numbers[i] > biggestNum)
        {
            biggestNum = numbers[i];
        }
    }
    Console.WriteLine();

    int sequenceCount = 0;
    int largestSequence = 0;
    int largestNumber = -1;

    for (int j = 0; j < biggestNum; j++)
    {
        for (int i = 0; i < numbers.Length; i++)
        {
            if (numbers[i] == j)
            {
                sequenceCount++;
            }
        }
        if (sequenceCount > largestSequence)
        {
            largestSequence = sequenceCount;
            largestNumber = j;
        }
        sequenceCount = 0;
    }

    Console.WriteLine("Most frequent number is {0}", largestNumber);
}

string ReverseString(string word)
{
    StringBuilder reverse = new StringBuilder();
    for (int i = word.Length - 1; i >= 0; i--)
    {
        reverse.Append(word[i]);
    }
    
    return reverse.ToString();
}

void ReverseGrammar(string word)
{
   
    string answer = String.Join(" ", word.Split('.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '"', '/', '!', '?').Reverse()).ToString();
    Console.WriteLine(answer); 
}

void Palindrome(string sentence)
{
    bool isUnique = true;
    List<string> unique = new List<string>();
    string[] words = sentence.Split(' ', '.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '"', '/', '!', '?');
    foreach(string word in words)
    {
        string reversed = ReverseString(word);
        if (word == reversed)
        {
            foreach(string uniques in unique)
            {
                if(uniques == word)
                {
                    isUnique = false;
                    break;
                }
            }
            if(isUnique)
            {
                unique.Add(word);
                Console.Write("{0}, ", word);
            }
            isUnique = true;
        }
    }
}

void URLParse(string url)
{
    //I don't understand Regex too well yet so this doesn't work
    List<string> resources = new List<string>();
    string divider = @"^(?<protocol>\w+)(?<server>://\w+)(?<resource>/\w+)?";
    foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(url, divider))
    {
        resources.Add(m.Groups[1].Value);
    }
    Console.WriteLine("Protocol: {0}", resources[0]);
    Console.WriteLine("Server: {0}", resources[1]);
    Console.WriteLine("Resource: {0}", resources[2]);
}