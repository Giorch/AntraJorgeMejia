﻿MVC -> 
Model 
View 
Controller -> a C# class that inherits from controller class
			-> contains action methods
			https://localhost:7177/home/index

			Views in MVC are called Razor viewwith cshtml extension (c# and html combined)