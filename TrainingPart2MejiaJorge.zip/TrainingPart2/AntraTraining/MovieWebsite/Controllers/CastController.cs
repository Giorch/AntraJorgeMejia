﻿using Microsoft.AspNetCore.Mvc;

namespace MovieWebsite.Controllers
{
    public class CastController : Controller
    {
        
    }
}
