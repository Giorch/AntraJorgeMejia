﻿using Microsoft.AspNetCore.Mvc;

namespace MovieWebsite.Controllers
{
    public class AccountController : Controller
    {
   
    }
}
