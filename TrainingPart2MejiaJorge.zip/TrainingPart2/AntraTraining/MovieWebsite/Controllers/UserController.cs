﻿using Microsoft.AspNetCore.Mvc;

namespace MovieWebsite.Controllers
{
    public class UserController : Controller
    {
       //[HttpGet]
       // public IActionResult Details(int id)
       // {
       //     return View();
       // } 
    }
}
