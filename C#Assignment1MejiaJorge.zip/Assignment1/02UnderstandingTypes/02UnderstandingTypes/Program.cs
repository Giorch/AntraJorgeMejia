﻿// See https://aka.ms/new-console-template for more information
while (true)
{

    Console.WriteLine("\n1. Values");
    Console.WriteLine("2. Century conversion");
    Console.WriteLine("3. FizzBuzz");
    Console.WriteLine("4. Byte loop");
    Console.WriteLine("5. Star Pyramid");
    Console.WriteLine("6. Guess the number");
    Console.WriteLine("7. Birth Date convertion");
    Console.WriteLine("8. Greetings");
    Console.WriteLine("9. Counting");
    Console.WriteLine("0. Exit");

    int selection;
    while (true)
    {
        string input = Console.ReadLine();
        if (Int32.TryParse(input, out selection))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }
    switch(selection)
    {
        case 0:
            return;
        case 1:
            ValueSize();
            break;
        case 2:
            CenturyConverison();
            break;
        case 3:
            FizzBuzz();
            break;
         case 4:
            ByteLoop();
            break;
        case 5:
            Pyramid();
            break;
        case 6:
            NumberGuessing();
            break;
        case 7:
            BirthDateToDays();
            break;
        case 8:
            Greeting();
            break;
        case 9:
            Counting();
            break;
    }
}

//1
void ValueSize()
{

    Console.WriteLine("SByte size: {0} \nSByte max value: {1} \nsByte min value: {2} \n", sizeof(sbyte), sbyte.MaxValue, sbyte.MinValue);
    Console.WriteLine("Byte size: {0} \nByte max value: {1} \nByte min value: {2} \n", sizeof(byte), byte.MaxValue, byte.MinValue);
    Console.WriteLine("Short size: {0} \nShort max value: {1} \nShort min value: {2} \n", sizeof(short), short.MaxValue, short.MinValue);
    Console.WriteLine("UShort size: {0} \nUShort max value: {1} \nUShort min value: {2} \n", sizeof(ushort), ushort.MaxValue, ushort.MinValue);
    Console.WriteLine("Int size: {0} \nInt max value: {1} \nInt min value: {2} \n", sizeof(int), int.MaxValue, int.MinValue);
    Console.WriteLine("UInt size: {0} \nUInt max value: {1} \nUInt min value: {2} \n", sizeof(uint), uint.MaxValue, uint.MinValue);
    Console.WriteLine("Long size: {0} \nLong max value: {1} \nLong min value: {2} \n", sizeof(long), long.MaxValue, long.MinValue);
    Console.WriteLine("ULong size: {0} \nULong max value: {1} \nULong min value: {2} \n", sizeof(ulong), ulong.MaxValue, ulong.MinValue);
    Console.WriteLine("Float size: {0} \nFloat max value: {1} \nFloat min value: {2} \n", sizeof(float), float.MaxValue, float.MinValue);
    Console.WriteLine("Double size: {0} \nDouble max value: {1} \nDouble min value: {2} \n", sizeof(double), double.MaxValue, double.MinValue);
    Console.WriteLine("Decimal size: {0} \nDecimal max value: {1} \nDecimal min value: {2} \n", sizeof(decimal), decimal.MaxValue, decimal.MinValue);
}

//2
void CenturyConverison()
{

    Console.Write("Enter Number of Centuries: ");
    int centuries;
    while (true)
    {
        string C = Console.ReadLine();
        if (Int32.TryParse(C, out centuries))
        {
            break;
        }
        Console.Write("Please enter a number");
    }
    int years = centuries * 100;
    int days = centuries * 36524;
    int hours = centuries * 876576;
    long minutes = centuries * 52594560;
    long seconds = centuries * 3155673600;
    ulong milliseconds = (ulong)centuries * 3155673600000;
    ulong microseconds = (ulong)centuries * 3155673600000000;
    ulong nanoseconds = (ulong)centuries * 3155673600000000000;

    Console.WriteLine("{0} centuries = {1} years = {2} days = 876576 hours = {3} minutes = {4} seconds = {5} milliseconds = {6} microseconds = {7} nanoseconds", centuries, years, days, hours, minutes, seconds, milliseconds, microseconds, nanoseconds);
}

//fizzbuzz
void FizzBuzz()
{
    Console.WriteLine("\n Fizzbuzz section");
    for (int i = 0; i < 100; i++)
    {
        string fizzbuzz = "";
        if (i % 3 == 0)
        {
            fizzbuzz = "fizz";
        }
        if (i % 5 == 0)
        {
            fizzbuzz += "buzz";
        }
        if (fizzbuzz == "")
        {
            fizzbuzz = "nb";
        }

        Console.WriteLine("Number: {0} \nResult: {1}", i, fizzbuzz);
    }
}

void ByteLoop()
{

    //Byte loop
    int max = 500;
    for (byte i = 0; i < max; i++)
    {
        Console.WriteLine(i);
        if (i >= byte.MaxValue)
        {
            Console.WriteLine("Warning: Index out of range of type's max size");
            break;
        }

    }
}


void Pyramid()
{

    //Pyramid
    //   *
    //  ***
    // *****
    //*******

    int rows;
    Console.Write("\nEnter pyramid size: ");
    while (true)
    {
        if (Int32.TryParse(Console.ReadLine(), out rows))
            break;

        Console.Write("Please enter a number: ");

    }
    for (int i = 0; i < rows; i++)
    {
        //num of spaces
        for (int j = 0; j < rows - i; j++)
        {
            Console.Write(" ");
        }

        //num of stars
        for (int k = 0; k < (i * 2) + 1; k++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
    }

}

void NumberGuessing()
{

    //Number guessing
    int correctNumber = new Random().Next(3) + 1;
    int userGuess;
    Console.Write("Guess the number between 1-3: ");
    while (true)
    {
        string input = Console.ReadLine();
        if (Int32.TryParse(input, out userGuess))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }

    if (userGuess > 3 || userGuess < 1)
    {
        Console.WriteLine("Input is out of range of possible correct guesses");
    }
    else if (userGuess > correctNumber)
    {
        Console.WriteLine("High");
    }
    else if (userGuess == correctNumber)
    {
        Console.WriteLine("Correct");
    }
    else if (userGuess < correctNumber)
    {
        Console.WriteLine("Low");
    }
}


void BirthDateToDays()
{

    int year;
    Console.Write("What year where you born: ");
    while (true)
    {
        string input = Console.ReadLine();
        if (Int32.TryParse(input, out year))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }
    int month;
    Console.Write("What month where you born: ");
    while (true)
    {
        string input = Console.ReadLine();
        if (Int32.TryParse(input, out month))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }
    int day;
    Console.Write("What day where you born: ");
    while (true)
    {

        string input = Console.ReadLine();
        if (Int32.TryParse(input, out day))
        {
            break;
        }
        Console.Write("Please enter a number: ");
    }

    int daysSince = (DateTime.Now.Year - year) * 365 + Math.Abs(DateTime.Now.Month - month) + Math.Abs(DateTime.Now.Day - day);
    int daysTillTenThousand = 10000 - (daysSince % 10000);
    Console.WriteLine("\nYou were born {0} days ago",daysSince);
    Console.WriteLine("And there's {0} days until your next 10000 day milestone", daysTillTenThousand);
}

void Greeting()
{
    if(DateTime.Now.Hour > 5 && DateTime.Now.Hour <= 11)
    {
        Console.WriteLine("Good Morning");
        return;
    }
    if(DateTime.Now.Hour > 11 && DateTime.Now.Hour <= 17)
    {
        Console.WriteLine("Good Afternoon");
        return;
    }
    if(DateTime.Now.Hour > 17 && DateTime.Now.Hour <= 20)
    {
        Console.WriteLine("Good Evening");
        return;
    }
    if(DateTime.Now.Hour > 20 || DateTime.Now.Hour <= 6)
    {
        Console.WriteLine("Good Night");
        return;
    }

}

void Counting()
{
    int result = 0;
    for(int i = 1; i <= 4; i++)
    {
        while(result != 24)
        {
            Console.Write("{0},",result);
            result += i;
        }
        Console.Write("{0}\n", result);
        result = 0;
    }
}