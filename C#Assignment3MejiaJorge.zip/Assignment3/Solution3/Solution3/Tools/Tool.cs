﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    internal class Tool
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ID { get; set; }

        public virtual void CreateTool(string name, string description, string id)
        {
            Name = name;
            Console.WriteLine("Name: {0}", Name);
            Description = description;
            Console.WriteLine("Description: {0}", Description);
            ID = id;
            Console.WriteLine("ID: {0}", ID);
        }

        public int GetID()
        {
            Console.WriteLine("Method 1. Returning ID of tool named {0}", Name);
            return int.Parse(ID);
        }

        public string GetID(string name)
        {
            if(name == Name)
            {
                Console.WriteLine("Method 2. Returning ID of tool named {0}", name);
                return ID;
            }
            Console.WriteLine("Tool doesn't have that name");
            return "";
        }
        
    }
}
