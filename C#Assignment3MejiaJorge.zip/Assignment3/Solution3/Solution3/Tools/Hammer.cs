﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    abstract class Hammer : Tool
    {
        int endurance;
        public override void CreateTool(string name, string description, string id)
        {
            base.CreateTool(name, description, id);
            endurance = 12;
            Console.WriteLine("Endurance: {0}", endurance);  
        }

        public abstract void UseHammer();
    }
}
