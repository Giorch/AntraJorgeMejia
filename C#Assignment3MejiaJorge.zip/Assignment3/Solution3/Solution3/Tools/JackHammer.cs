﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    internal class JackHammer : Hammer
    {
        public override void UseHammer()
        {
            Console.WriteLine("TRRRRRRRRRRRR (it's a jackhammer noise)");
        }
    }
}
