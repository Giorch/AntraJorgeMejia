﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3.School
{
    internal class Department : Solution3.Interfaces.IDepartmentService
    {
        public Instructor Head { get; set; } = new Instructor();
        public List<Instructor> Instructors { get; set; } = new List<Instructor>();
        int budget;
        public List<Course> Courses { get; set; } = new List<Course>();

        public void PrintCourses()
        {
            foreach(var course in Courses)
            {
                Console.WriteLine(course);
            }
        }
    }
}
