﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Solution3.School;

namespace Solution3
{
    internal class Student : Person, Solution3.Interfaces.IStudentService
    {
        
        public List<Course> courses { get; set; }

        public override void CreatePerson(string name, int id)
        {
            base.name = name;
            Console.WriteLine(base.name);
            Id = id;
            Console.WriteLine(Id);
            
        }


        public char GetGrade(Course course)
        {
            return course.grade;
        }
    }
}
