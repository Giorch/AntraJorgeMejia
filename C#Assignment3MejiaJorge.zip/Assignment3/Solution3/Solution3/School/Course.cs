﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Solution3.School
{
    internal class Course : Solution3.Interfaces.ICourseService
    {
        public string Name { get; set; }
        public char grade { get; set; }
        List<Student> students { get; set; } = new List<Student>();

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void PrintStudents()
        {
            foreach(Student student in students)
            {
                Console.WriteLine(student);
            }
        }
    }
}
