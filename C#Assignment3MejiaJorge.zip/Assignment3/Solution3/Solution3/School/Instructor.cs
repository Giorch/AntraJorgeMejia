﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Solution3.School;
namespace Solution3
{
    internal class Instructor : Person, Solution3.Interfaces.IInstructorService
    {

        //Variables that matter
        Department department;
        int joinYear;

        public override void CreatePerson(string name, int id)
        {
            base.name = name;
            Console.WriteLine(base.name);
            Id = id;
            Console.WriteLine(Id);
           
        }

        public void JoinDepartment(Department departments)
        {
            if(departments.Instructors.Count == 0)
            departments.Head = this;

            departments.Instructors.Add(this);
            department = departments;
            
        }
    }
}
