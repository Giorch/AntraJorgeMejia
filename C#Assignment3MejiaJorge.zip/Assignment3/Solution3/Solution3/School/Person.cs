﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    abstract class Person : Solution3.Interfaces.IPersonService
    {
        public int Id { get; set; }
        public string name { get; set; }
        public int salary { get; set; }
        public int age { get; set; }
        public string address { get; set; }

        public int CalculateAge()
        {
            return age;
        }

        public float CalculateSalary()
        {
            return salary;
        }

        public abstract void CreatePerson(string name, int id);

        public string GetAddress()
        {
            return address;
        }
    }
}
