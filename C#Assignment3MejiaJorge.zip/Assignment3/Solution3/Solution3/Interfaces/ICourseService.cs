﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3.Interfaces
{
    internal interface ICourseService
    {
        void AddStudent(Student student);
        void PrintStudents();
    }
}