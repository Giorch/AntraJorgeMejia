﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Solution3.School;
namespace Solution3.Interfaces
{
    internal interface IInstructorService
    {
        void JoinDepartment(Department department);
    }
}
