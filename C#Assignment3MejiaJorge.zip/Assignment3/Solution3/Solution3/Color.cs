﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    internal class Color
    {
        public byte red { get; set; }
        public byte green { get; set; }
        public byte blue { get; set; }
        public byte alpha { get; set; }

        public Color(byte R, byte G, byte B)
        {
            red = R;
            green = G;
            blue = B;
            alpha = 255;
        }
        public Color(byte R, byte G, byte B, byte A)
        {
            red = R;
            green = G;
            blue = B;
            alpha = A;
        }

        public int GetGrayScale()
        {
            int gray = (red + green + blue)/3;
            return gray;
        }
    }
}
