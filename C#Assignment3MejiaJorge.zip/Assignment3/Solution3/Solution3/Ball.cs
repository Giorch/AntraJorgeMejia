﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Solution3;

namespace Solution3
{
    internal class Ball
    {
        public int size { get; set; }
        public Color color { get; set; }
        public int timesThrown { get; set; }

        public Ball(int S, Color C)
        {
            size = S;
            color = C;
        }
        public Ball(int S)
        {
            size = S;
            color = new Color(255, 255, 255);
        }

        public void Pop()
        {
            Console.WriteLine("*POP*");
            timesThrown = 0;
        }

        public void Throw()
        {
            Console.WriteLine("*Boing*");
            timesThrown++;
        }

        public int GetThrowCount()
        {
            return timesThrown;
        }

    }
}
