﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using Solution3;
using Solution3.School;

            Course course = new Course();
Student student1 = new Student();
    Student student2 = new Student();
    Student student3 = new Student();
    Instructor instructor = new Instructor();
while (true)
{

    Console.WriteLine("\n1. Reverse array");
    Console.WriteLine("2. Fibonacci");
    Console.WriteLine("3. OOP Demonstration");
    Console.WriteLine("4. Abstraction and Inheritance (Create students and instructor)");
    Console.WriteLine("5. Encapsulation (Show student and instructor data");
    Console.WriteLine("6. Polymorphism");
    Console.WriteLine("7. Ball & Color");
    Console.WriteLine("0. Exit");

    Console.WriteLine("Select an option");
    int input = ReadNum();
    switch (input)
    {
        case 0:
            return;
        case 1:
            Console.WriteLine("Array size: ");
            int arrSize = ReadNum();
            int[] numbers = GenerateNumbers(arrSize);
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write("{0} ", numbers[i]);
            }
            Console.WriteLine();
            Reverse(ref numbers);
            PrintNumbers(numbers);
            break;
        case 2:
            Console.WriteLine("Select an index: ");
            int index = ReadNum();
            Console.WriteLine(Fibonaacci(index));
            break;
        case 3:
            Console.WriteLine("\nCreating and setting a tool's encapsulated fields\n");
            Tool screwdriver = new Tool();
            screwdriver.CreateTool("Screwdriver", "A tool to screw and unscrew", "1");
            Console.WriteLine("\nGetting tool's ID through 2 overloaded functions\n");
            screwdriver.GetID();
            screwdriver.GetID("Screwdriver");
            Console.WriteLine("\nCreating tool from derived class Hammer\n");
            JackHammer jackHammer = new JackHammer();
            jackHammer.CreateTool("Jackhammer", "A hammer that hits the ground very fast", "02");
            Console.WriteLine("\nUsing absract method from derived class of Hammer\n");
            jackHammer.UseHammer();
            break;
        case 4:
            course.Name = "Math";
            Console.WriteLine("Creating Students");
            student1.CreatePerson("Sasha", 1);
            Console.WriteLine();
            student2.CreatePerson("Alex", 2);
            Console.WriteLine();
            student3.CreatePerson("Mario", 3);
            Console.WriteLine();
            Console.WriteLine("Creating Instructor");
            instructor.CreatePerson("Martha", 1);
            Console.WriteLine("\nAssigned students to instructor course");
            course.AddStudent(student1);
            course.AddStudent(student2);
            course.AddStudent(student3);
            Console.WriteLine("Graded Sasha");
            student1.courses[1].grade = 'B';
            Console.WriteLine("Graded Alex");
            student1.courses[1].grade = 'C';
            Console.WriteLine("Graded Mario");
            student1.courses[1].grade = 'A';
            break;
        case 5:

            Console.WriteLine("Showing students in Math course");
            course.PrintStudents();
            Console.WriteLine();
            break;
        case 6:
            Console.WriteLine("Creating tool with original function");
            Tool wrench = new Tool();
            wrench.CreateTool("Wrench", "Used to get a grip on nuts and bolts", "4");
            Console.WriteLine("Creating tool with overwritten function");
            JackHammer sledgeHammer = new JackHammer();
            sledgeHammer.CreateTool("Sledgehammer", "A very big and heavy hammer for very big and heavy nails", "5");
            break;
        case 7:
            Ball ball = new Ball(5);
            Console.WriteLine("Ball size: {0}\nBall color: {1} {2} {3} {4}", ball.size, ball.color.red, ball.color.green, ball.color.blue, ball.color.alpha);
            ball.Throw();
            ball.Throw();
            ball.Throw();
            Console.WriteLine("Throw Count: {0}", ball.GetThrowCount());
            ball.Pop();
            Console.WriteLine("Throw Count: {0}", ball.GetThrowCount());
            Console.WriteLine("Ball color's grayscale value: {0}", ball.color.GetGrayScale());
            Console.WriteLine("Changing ball's color");
            ball.color.red = 53;
            ball.color.green = 23;
            ball.color.blue = 100;
            ball.color.alpha = 200;

            Console.WriteLine("Ball size: {0}\nBall color: {1} {2} {3} {4}", ball.size, ball.color.red, ball.color.green, ball.color.blue, ball.color.alpha);

            break;

    }

}




int[] GenerateNumbers(int length)
{
    int[] vs = new int[length];
    for (int i = 0; i < length; i++)
    {
        vs[i] = i + 1;
    }
    return vs;
}

void Reverse(ref int[] numbers)
{
    int[] temp = new int[numbers.Length];
    for (int i = numbers.Length - 1, j = 0; i >= 0; i--, j++)
    {
        temp[j] = numbers[i];
    }

    numbers = temp;
}

void PrintNumbers(int[] numbers)
{
    for(int i = 0; i < numbers.Length; i++)
    {
        Console.Write("{0} ", numbers[i]);
    }
    Console.WriteLine('\n');
}

int ReadNum()
{
    int input;
    while(true)
    {
        
        if(int.TryParse(Console.ReadLine(), out input))
        {
            return input;
        }
        Console.Write("Please enter a number: ");
    }
}

int Fibonaacci(int index)
{
    if(index == 1 || index == 2)
    {
        return 1;
    }
    int result = 0;
    int number1 = 1;
    int number2 = 1;
    for(int i = 2; i < index; i++)
    {
        result = number1 + number2;
        number1 = number2;
        number2 = result;
    }
    return result;
}